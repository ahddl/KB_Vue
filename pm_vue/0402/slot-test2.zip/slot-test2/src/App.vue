<script setup>
import NoSlotTest from './components/NoSlotTest.vue';
import SlotTest from './components/SlotTest.vue';
</script>

<template>
  <div><NoSlotTest /></div>
  <div><SlotTest /></div>
</template>
