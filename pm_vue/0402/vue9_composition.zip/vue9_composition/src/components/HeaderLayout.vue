<script setup></script>

<template>
  <header class="hd">
    <h1>작심</h1>
  </header>
</template>

<style scoped>
/* 앱제목 header */
.hd {
  background-color: var(--gray700);
  padding: var(--space-l) 0 calc(var(--space-l) * 1.8);
  text-align: center;
}
.hd h1 {
  font-family: 'Noto Sans KR', sans-serif;
  font-size: 2rem;
  font-weight: 500;
}
</style>
